@extends('layouts.main')
@section('assets')
<link rel="stylesheet" href="css/custom.css">
<?php
$title = 'Order';
?>
@endsection
@section('content')
<!--== Start Page Header Area ==-->
<div class="page-header-wrapper bg-offwhite">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="page-header-content d-flex">
                    <h2 style="font-size:40px; font-weight:500;">
                        English as a second Language <br>
                        <p style="font-size:22px;">Editing and proofreading servicesl</p>

                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!--== End Page Header Area ==-->
<!--== Start Page Content Wrapper ==-->
<div class="page-wrapper">
    <div class="icon-box-item-1 pt-120 pt-md-80 pt-sm-60 pb-120 pb-md-80 pb-sm-60">
        <div class="container">
            
        </div>
    </div>

    <div class="container clearfix">

    </div>

</div>

<!--== End Page Content Wrapper ==-->
@endsection
@section('scripts')

@endsection
