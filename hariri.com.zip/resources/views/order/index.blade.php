@extends('layouts.main')
@section('assets')
<link rel="stylesheet" href="css/custom.css">
<?php
$title = 'Order';
?>
@endsection
@section('content')
<!--== Start Page Header Area ==-->
<div class="page-header-wrapper bg-offwhite">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="page-header-content d-flex">
                    <h2 style="font-size:40px; font-weight:500;">
                        Order Here In Three Simple Steps <br>
                        <p style="font-size:22px;">Safe, Secure, Confidential</p>

                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!--== End Page Header Area ==-->
<!--== Start Page Content Wrapper ==-->
<div class="page-wrapper">
    <div class="icon-box-item-1 pt-120 pt-md-80 pt-sm-60 pb-120 pb-md-80 pb-sm-60">
        <div class="container">
            <div class="row mtm-60 mtm-sm-0 mtm-md-0">
                <!-- Start Single Welcome Feature -->
                <div class="col-md-6 col-lg-4">
                    <div class="single-welcome-feature d-flex">
                        <div class="feature-icon">
                            <i class="fa fa-codepen"></i>
                        </div>
                        <div class="feature-info">
                            <h3>Certified Private</h3>
                            <p>Confidentiality guaranteed.</p>
                        </div>
                    </div>
                </div>
                <!-- End Single Welcome Feature -->
                <!-- Start Single Welcome Feature -->
                <div class="col-md-6 col-lg-4">
                    <div class="single-welcome-feature d-flex">
                        <div class="feature-icon">
                            <i class="fa fa-file-o"></i>
                        </div>

                        <div class="feature-info">
                            <h3>Money-Back Promise</h3>
                            <p>Don't pay if you're not happy.</p>
                        </div>
                    </div>
                </div>
                <!-- End Single Welcome Feature -->
                <!-- Start Single Welcome Feature -->
                <div class="col-md-6 col-lg-4">
                    <div class="single-welcome-feature d-flex">
                        <div class="feature-icon">
                            <i class="fa fa-folder-open-o"></i>
                        </div>

                        <div class="feature-info">
                            <h3>100% Secure Checkout</h3>
                            <p>Certified private connection.</p>
                        </div>
                    </div>
                </div>
                <!-- End Single Welcome Feature -->

            </div>
        </div>
    </div>

    <div class="container clearfix">
        
    </div>

</div>

<!--== End Page Content Wrapper ==-->
@endsection
@section('scripts')

@endsection
