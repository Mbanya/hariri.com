<?php $__env->startSection('assets'); ?>

<?php
$title = 'Package';
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--== Start Page Header Area ==-->
<div class="page-header-wrapper bg-offwhite" style="background-image:url('images/)">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="page-header-content d-flex">
                    <h2 style="font-size:45px; font-weight:700;">
                        <?php echo e($package->name); ?> <br>
                        <p style="font-size:20px; font-weight:500;">
                            <?php echo e($package->sub_heading); ?>

                        </p>
                        
                       
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!--== End Page Header Area ==-->
<!--== Start Page Content Wrapper ==-->
<div class="page-wrapper">
    <div class="icon-box-item-1 pt-120 pt-md-80 pt-sm-60 pb-120 pb-md-80 pb-sm-60">
        <div class="container">
            <?php echo $package->description; ?>

        </div>
    </div>

    <div class="container clearfix">
        <h4>Select a service to get an instant quote.</h4>
        <div class="row no-gutters">
            <?php $__currentLoopData = $package->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <!-- Start Single Custom Search Item #01 -->
            <div class="col-lg-4 col-sm-6 text-center">
                    <div class="single-custom-search-item">
                    <h2><?php echo e($item->name); ?></h2>
                        <p>
                            <?php echo e($item->sub_heading_description); ?>

                        </p>
                    <a href="<?php echo e(route('service.show',$item->slug)); ?>" class="btn-know-more">+ Know More</a>
                    </div>
                </div>
                <!-- End Single Custom Search Item #01 -->  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>

<!--== End Page Content Wrapper ==-->
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hariri.com\resources\views/packages/show.blade.php ENDPATH**/ ?>