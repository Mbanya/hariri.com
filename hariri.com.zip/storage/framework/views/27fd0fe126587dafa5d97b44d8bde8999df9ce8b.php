<?php $__env->startSection('assets'); ?>

<?php
$title = 'Package';
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--== Start Page Header Area ==-->
<div class="page-header-wrapper bg-offwhite" style="background-image:url('images/)">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="page-header-content d-flex">
                    <h2 style="font-size:45px; font-weight:700;">
                        <?php echo e($service->name); ?> <br>
                        <p style="font-size:20px; font-weight:500;">
                            <?php echo e($service->sub_heading); ?>

                        </p>
                        
                       
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!--== End Page Header Area ==-->
<!--== Start Page Content Wrapper ==-->
<div class="page-wrapper">
    <div class="icon-box-item-1 pt-120 pt-md-80 pt-sm-60 pb-120 pb-md-80 pb-sm-60">
        <div class="container">
            <?php echo $service->description; ?>

        </div>
    </div>

    <div class="container clearfix">
        <h4>Get an Instant Quote and Place Your Order.</h4>
        <form action="post">
        <div class="row" style="padding-bottom:50px;">
            
                    <div class="col-md-2"></div>
                    <div class="col-md-6">
                        <p style="font-size:15px;"> <strong>Enter the word count of your documents:</strong>
                        <br>
                        <i style="padding-top: 7px; font-size:0.9em; font-weight: normal;">Include footnotes and endnotes if you want us to review them.</i>
                        </p>
                        
                    </div>
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="word_count" value="0"  id="word_count">
                    </div>
        
                    <div class="col-md-2"></div>
                    <div class="col-md-6">
                        <p>
                            <strong>
                                Show your quote in this currency:
                            </strong>
                        </p>
                    </div>
                    <div class="col-md-4">
        
                       <select name="currency" class="form-control" id="currency">
                           <option value="usd">Us Dollars</option>
                           <option value="ksh">Kenya Shilling</option>
                       </select>
                    </div>

                    

            
            
        </div>

          <table class="table-striped" style="padding-top:100px;" cellpadding="2" width="100%" cellspacing="0">
              <thead class="thead-dark">
                  <tr>

                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td><?php echo e($service->name); ?></td>
                      <td>(up to 1,500 words)</td>
                      <td>4 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 4000 words)</td>
                        <td>4 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 1,500 words)</td>
                        <td>8 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 6000 words)</td>
                        <td>12 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 10,000 words)</td>
                        <td>24 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 25,000 words)</td>
                        <td>48 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 40,000 words)</td>
                        <td>72 hours</td>
                  </tr>
                  <tr>
                        <td><?php echo e($service->name); ?></td>
                        <td>(up to 65,000 words)</td>
                        <td>1 week </td>
                  </tr>
              </tbody>
          </table>

          <div class="quote text-right mt-25">
                <button type="submit" class="btn btn-lg- btn-scrib-cta mb-10" id="create_quote" name="create_quote" >
                    <span class="fa fa-calculator"></span>
                    <span class="confirm"><span class="notranslate">&nbsp;</span>Calculate Quote</span>
                </button>
          </div>
         
        </form>
    </div>

</div>

<!--== End Page Content Wrapper ==-->
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<style>
.text-right{
    text-align: right;
}
.mb-10 {
    margin-bottom: 10px!important;
}
.mt-25 {
    margin-top: 25px!important;
}
.btn-scrib-cta {
    background-color: #ffbe00;
    border: 1px solid #ffb400;
    color: #fff;
}
.btn-group-lg>.btn, .btn-lg {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
}
.btn-lg-1 {
    border-radius: 4px;
}
button, input, optgroup, select, textarea {
    color: inherit;
    font: inherit;
    margin: 0;
}
</style>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hariri.com\resources\views/service/show.blade.php ENDPATH**/ ?>